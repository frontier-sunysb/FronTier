#ifndef SUPPORT_DH
#define SUPPORT_DH

#include "euclid_common.h"

extern void shellSort_int(const int n, int *x);
extern void shellSort_float(int n, double *v);

/*
extern void shellSort_int_int(const int n, int *x, int *y);
extern void shellSort_int_float(int n, int *x, double *v);
extern void shellSort_int_int_float(int n, int *x, int *y, double *v);
*/

#endif
