#ifndef _Utils_h_
#define _Utils_h_

class Utils {
 public:
   static void appendToCharArrayList(char**& strings, int& numStrings,
                                     char** stringsToAdd, int numStringsToAdd);

   static int getParam(const char* flag, int numParams, char** strings, char* param);

   static int sortedIntListFind(int item,const int* list, int len, int* insert);

   static int intListFind(int item, const int* list, int len);

   static int sortedGlobalIDListFind(GlobalID item, const GlobalID* list,
                                     int len, int* insert);

   static int sortedIntListInsert(int item, int*& list, int& len,
                                  int& allocatedLength);

   static int sortedGlobalIDListInsert(GlobalID item, GlobalID*& list,int& len,
                                       int& allocatedLength);

   static void intListInsert(int item, int index, int*& list, int& len,
                             int& allocatedLength);

   static void doubleListInsert(double item, int index, double*& list,int& len,
                             int& allocatedLength);

   static void GlobalIDListInsert(GlobalID item, int index, GlobalID*& list,
                                  int& len, int& allocatedLength);

   static void doubleArrayListInsert(int index, feiArray<double>**& daList, int& len);

   static void intArrayListInsert(int index, feiArray<int>**& iaList, int& len);

   static void intTableInsertRow(int* newRow, int whichRow,
                                 int**& table, int& numRows);

   static void doubleTableInsertRow(double* newRow, int whichRow,
                                    double**& table, int& numRows);

   static void appendIntList(int newItem, int*& list, int& lenList);

   static bool inList(int* list, int lenList, int item);
};

#endif

